"""
Business Dashboard - Flask Backend
-----------------------------------
Ye Flask app matplotlib wale static dashboard (10-Professional_Advanced_Dashboard.py)
ko ek dynamic, browser-based dashboard mein convert karta hai.

Kaam:
1. Startup par sales_data.csv (isi folder mein) read karta hai
2. Uska data JSON API (/api/data) ke through frontend ko deta hai
3. User browser se naya CSV upload kar sakta hai (/api/upload) -> dashboard
   bina page reload ke live update ho jata hai
4. "Reset" button se wapas original sales_data.csv par aa sakte hain
"""

import io
import os

import pandas as pd
from flask import Flask, jsonify, render_template, request

app = Flask(__name__)

# Ye csv file app.py ke sath hi honi chahiye (isi folder mein)
CSV_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sales_data.csv")

REQUIRED_COLUMNS = ["Month", "Sales", "Profit", "Advertisement", "Customers"]

# Abhi jo dataset dikhaya ja raha hai woh memory mein rakhte hain
# (upload ke baad disk par dobara likhne ki zaroorat nahi)
current_df = None


def clean_dataframe(df):
    """Required columns check karta hai aur numeric columns ko safe number banata hai."""
    missing = [col for col in REQUIRED_COLUMNS if col not in df.columns]
    if missing:
        raise ValueError(
            f"CSV mein ye columns missing hain: {', '.join(missing)}. "
            f"Required columns: {', '.join(REQUIRED_COLUMNS)}"
        )

    df = df.copy()
    for col in ["Sales", "Profit", "Advertisement", "Customers"]:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
    return df


def load_default_data():
    """Startup ya reset par default sales_data.csv load karta hai."""
    global current_df
    df = pd.read_csv(CSV_PATH)
    current_df = clean_dataframe(df)
    return current_df


def build_payload(df):
    """DataFrame ko JSON-friendly dictionary (chart data + KPIs) mein convert karta hai."""
    total_sales = float(df["Sales"].sum())
    total_profit = float(df["Profit"].sum())
    total_ad_spend = float(df["Advertisement"].sum())
    total_customers = int(df["Customers"].sum())

    def pct_change(series):
        # Pehle mahine vs aakhri mahine ke beech growth %
        if len(series) < 2 or series.iloc[0] == 0:
            return 0.0
        return float((series.iloc[-1] - series.iloc[0]) / series.iloc[0] * 100)

    return {
        "months": df["Month"].astype(str).tolist(),
        "sales": df["Sales"].tolist(),
        "profit": df["Profit"].tolist(),
        "advertisement": df["Advertisement"].tolist(),
        "customers": df["Customers"].tolist(),
        "kpis": {
            "total_sales": total_sales,
            "total_profit": total_profit,
            "total_ad_spend": total_ad_spend,
            "total_customers": total_customers,
            "sales_growth_pct": round(pct_change(df["Sales"]), 1),
            "profit_growth_pct": round(pct_change(df["Profit"]), 1),
            "customer_growth_pct": round(pct_change(df["Customers"]), 1),
            "profit_margin_pct": round(
                (total_profit / total_sales * 100) if total_sales else 0, 1
            ),
        },
    }


@app.route("/")
def index():
    """Main dashboard page render karta hai."""
    return render_template("index.html")


@app.route("/api/data")
def get_data():
    """Abhi wala dataset (default ya upload kiya hua) JSON format mein deta hai."""
    global current_df
    try:
        if current_df is None:
            load_default_data()
        return jsonify({"ok": True, "data": build_payload(current_df), "source": "current"})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400


@app.route("/api/upload", methods=["POST"])
def upload_data():
    """
    Browser se naya CSV file upload handle karta hai.
    Frontend se multipart/form-data ke sath 'file' field aani chahiye.
    """
    global current_df

    if "file" not in request.files:
        return jsonify({"ok": False, "error": "Koi file upload nahi hui."}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"ok": False, "error": "File ka naam khali hai."}), 400

    if not file.filename.lower().endswith(".csv"):
        return jsonify({"ok": False, "error": "Sirf .csv files allowed hain."}), 400

    try:
        raw_bytes = file.read()
        new_df = pd.read_csv(io.BytesIO(raw_bytes))
        new_df = clean_dataframe(new_df)
    except Exception as e:
        return jsonify({"ok": False, "error": f"CSV parse nahi ho saki: {e}"}), 400

    current_df = new_df
    return jsonify({"ok": True, "data": build_payload(current_df), "source": "upload"})


@app.route("/api/reset", methods=["POST"])
def reset_data():
    """Wapas original sales_data.csv par reset karta hai."""
    try:
        load_default_data()
        return jsonify({"ok": True, "data": build_payload(current_df), "source": "default"})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400


if __name__ == "__main__":
    # Startup par ek dafa CSV check kar lete hain taake error jaldi pata chal jaye
    load_default_data()
    print(f"Data file: {CSV_PATH}")
    print("Dashboard yahan khulega: http://127.0.0.1:5000")
    # debug=True sirf development ke liye hai
    app.run(debug=True, host="0.0.0.0", port=5000)
