# Business Dashboard (Flask + Chart.js)

Aapki matplotlib script `10-Professional_Advanced_Dashboard.py` ka dynamic web version — "Executive Ledger" theme.

## IMPORTANT: Folder structure kabhi mat todein

Extract karne ke baad ye poora folder jaisa hai waisa hi rakhein — `app.py` ke
bilkul sath (usi level par) `templates/` aur `static/` folders hone chahiye:

```
business-dashboard/
├── app.py
├── sales_data.csv
├── requirements.txt
├── templates/
│   └── index.html
└── static/
    ├── css/style.css
    ├── js/dashboard.js
    └── vendor/chart.umd.js
```

## Run karne ka tareeqa

```bash
cd business-dashboard
pip install -r requirements.txt
python app.py
```

Terminal mein link dikhega — usi ko browser mein kholein: `http://127.0.0.1:5000`

## Charts show nahi ho rahe the? Ye fix ho gaya hai

Pehle Chart.js ek **external CDN** (cdnjs.cloudflare.com) se load hoti thi.
Agar aapke internet/network par woh CDN block ya slow ho, to Chart.js load hi
nahi hoti thi — is wajah se saari charts khali reh jati thin, sirf KPI cards
dikhte the.

**Fix:** Chart.js ki file ab isi project ke andar hi rakhi hui hai
(`static/vendor/chart.umd.js`), koi internet dependency nahi — poora
dashboard offline bhi chalega.

Agar phir bhi charts na dikhein, browser mein **F12 -> Console tab** kholein
aur wahan red error message copy karke bhejein — turant fix kar dunga.

## CSV Upload (dynamic)

Dashboard ke top-right mein **"Browse & import CSV"** button hai:

1. Click karein — file-browser khulega
2. `.csv` file select karein jisme ye 5 columns hon:
   `Month, Sales, Profit, Advertisement, Customers`
3. Dashboard turant naye data se update ho jayega (KPIs + saare 4 charts)
4. **"Reset to default"** se wapas original `sales_data.csv` par aa sakte hain

## Features

- 4 KPI cards — animated count-up
- 4 charts (Sales Trend, Profit Trend, Ad vs Sales bubble, Customer Growth bar)
- Live CSV upload + reset
- Fully offline-capable (Chart.js bundled locally, koi CDN dependency nahi)
- Responsive design

## Files

- `app.py` — Flask backend (`/api/data`, `/api/upload`, `/api/reset`)
- `templates/index.html` — dashboard structure
- `static/css/style.css` — theme
- `static/js/dashboard.js` — Chart.js rendering + upload logic
- `static/vendor/chart.umd.js` — Chart.js library (local copy, koi CDN nahi)
- `sales_data.csv` — aapka actual sales data
