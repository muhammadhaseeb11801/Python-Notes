/*
 * Business Dashboard - Frontend Logic
 * ------------------------------------
 * Ye file 3 kaam karti hai:
 * 1. /api/data se data fetch karke KPI cards aur 4 charts render karti hai
 * 2. CSV upload handle karti hai (bina page reload ke dashboard update)
 * 3. Charts ko "Executive Ledger" theme ke colors ke sath style karti hai
 */

// ===== Theme colors (CSS variables ke sath match karte hain) =====
const COLORS = {
  gold: "#C9A227",
  green: "#5FAE7F",
  red: "#C1443C",
  parchment: "#EDE6D6",
  slate: "#8C99B3",
  hairline: "rgba(237,230,214,0.12)",
  navy800: "#1B2740",
};

// Chart.js ke liye common (shared) styling defaults
Chart.defaults.font.family = "'IBM Plex Mono', monospace";
Chart.defaults.font.size = 11;
Chart.defaults.color = COLORS.slate;

let charts = {}; // active chart instances ka reference (dobara render karne ke liye)

// ---------- Helpers ----------

function formatCompact(num) {
  // Bade numbers ko chota karke dikhata hai, e.g. 71000 -> 71.0K
  if (num >= 1_000_000) return (num / 1_000_000).toFixed(2) + "M";
  if (num >= 1_000) return (num / 1_000).toFixed(1) + "K";
  return Math.round(num).toString();
}

function animateNumber(el, targetValue, { prefix = "", isInt = false, duration = 900 } = {}) {
  // KPI number ko 0 se target tak "count up" animate karta hai
  const start = 0;
  const startTime = performance.now();

  function tick(now) {
    const progress = Math.min((now - startTime) / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic
    const current = start + (targetValue - start) * eased;
    el.textContent = prefix + (isInt ? Math.round(current).toLocaleString() : formatCompact(current));
    if (progress < 1) requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
}

function setDelta(el, pct, label = "vs. first period") {
  if (!el) return;
  const sign = pct > 0 ? "+" : "";
  el.textContent = `${sign}${pct}% ${label}`;
  el.classList.remove("pos", "neg");
  el.classList.add(pct >= 0 ? "pos" : "neg");
}

function destroyCharts() {
  Object.values(charts).forEach((c) => c && c.destroy());
  charts = {};
}

// ---------- KPI rendering ----------

function renderKPIs(kpis) {
  animateNumber(document.getElementById("kpi-sales"), kpis.total_sales, { prefix: "$" });
  animateNumber(document.getElementById("kpi-profit"), kpis.total_profit, { prefix: "$" });
  document.getElementById("kpi-margin").textContent = kpis.profit_margin_pct + "%";
  animateNumber(document.getElementById("kpi-customers"), kpis.total_customers, { isInt: true });

  setDelta(document.getElementById("kpi-sales-delta"), kpis.sales_growth_pct);
  setDelta(document.getElementById("kpi-profit-delta"), kpis.profit_growth_pct);
  setDelta(document.getElementById("kpi-customers-delta"), kpis.customer_growth_pct);
}

// ---------- Chart rendering ----------

function renderCharts(data) {
  destroyCharts();

  const gridColor = COLORS.hairline;
  const commonScales = {
    x: { grid: { color: gridColor }, ticks: { color: COLORS.slate } },
    y: { grid: { color: gridColor }, ticks: { color: COLORS.slate } },
  };

  // --- Exhibit A: Sales trend (line) ---
  charts.sales = new Chart(document.getElementById("chart-sales"), {
    type: "line",
    data: {
      labels: data.months,
      datasets: [{
        label: "Sales",
        data: data.sales,
        borderColor: COLORS.gold,
        backgroundColor: "rgba(201,162,39,0.12)",
        pointBackgroundColor: COLORS.gold,
        borderWidth: 2.5,
        pointRadius: 3,
        tension: 0.3,
        fill: true,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: commonScales,
    },
  });

  // --- Exhibit B: Profit trend (dashed line) ---
  charts.profit = new Chart(document.getElementById("chart-profit"), {
    type: "line",
    data: {
      labels: data.months,
      datasets: [{
        label: "Profit",
        data: data.profit,
        borderColor: COLORS.green,
        backgroundColor: "rgba(95,174,127,0.1)",
        pointBackgroundColor: COLORS.green,
        borderWidth: 2.5,
        borderDash: [6, 4],
        pointRadius: 3,
        tension: 0.3,
        fill: true,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: commonScales,
    },
  });

  // --- Exhibit C: Advertisement vs Sales (bubble, size = customers) ---
  const bubbleData = data.months.map((m, i) => ({
    x: data.advertisement[i],
    y: data.sales[i],
    r: Math.max(4, Math.min(22, data.customers[i] / 12)),
    month: m,
  }));
  charts.scatter = new Chart(document.getElementById("chart-scatter"), {
    type: "bubble",
    data: {
      datasets: [{
        label: "Ad vs Sales",
        data: bubbleData,
        backgroundColor: "rgba(201,162,39,0.55)",
        borderColor: COLORS.gold,
        borderWidth: 1,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (ctx) => {
              const p = ctx.raw;
              return `${p.month}: Ad $${formatCompact(p.x)} · Sales $${formatCompact(p.y)}`;
            },
          },
        },
      },
      scales: {
        x: { ...commonScales.x, title: { display: true, text: "Advertisement ($)", color: COLORS.slate } },
        y: { ...commonScales.y, title: { display: true, text: "Sales ($)", color: COLORS.slate } },
      },
    },
  });

  // --- Exhibit D: Customer growth (bar) ---
  charts.customers = new Chart(document.getElementById("chart-customers"), {
    type: "bar",
    data: {
      labels: data.months,
      datasets: [{
        label: "Customers",
        data: data.customers,
        backgroundColor: "rgba(201,162,39,0.65)",
        hoverBackgroundColor: COLORS.gold,
        borderRadius: 2,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: commonScales,
    },
  });
}

// ---------- Data loading ----------
// sales_data.csv Flask backend se load hota hai; upload/reset ke baad bhi
// isi function se dobara data fetch karke charts refresh hote hain

async function loadDashboard(url = "/api/data", options = undefined) {
  const statusEl = document.getElementById("upload-status");
  try {
    const res = await fetch(url, options);
    const json = await res.json();

    if (!json.ok) {
      throw new Error(json.error || "Kuch ghalat ho gaya.");
    }

    renderKPIs(json.data.kpis);
    renderCharts(json.data);

    const labelEl = document.getElementById("data-source-label");
    if (json.source === "upload") labelEl.textContent = "uploaded dataset";
    else if (json.source === "default") labelEl.textContent = "sales_data.csv (default)";

    document.getElementById("spine-period").textContent =
      `${json.data.months.length} MO`;

    if (statusEl) {
      statusEl.textContent = json.source === "upload" ? "Upload successful ✓" : "";
      statusEl.className = "upload-status is-ok";
    }
  } catch (err) {
    if (statusEl) {
      statusEl.textContent = err.message;
      statusEl.className = "upload-status is-error";
    }
    console.error(err);
  }
}

// ---------- Event wiring ----------

document.getElementById("csv-input").addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (!file) return;

  const formData = new FormData();
  formData.append("file", file);

  loadDashboard("/api/upload", { method: "POST", body: formData });
  e.target.value = ""; // taake wohi file dobara select ho sake
});

document.getElementById("reset-btn").addEventListener("click", () => {
  loadDashboard("/api/reset", { method: "POST" });
});

// ---------- Initial load ----------
loadDashboard();
